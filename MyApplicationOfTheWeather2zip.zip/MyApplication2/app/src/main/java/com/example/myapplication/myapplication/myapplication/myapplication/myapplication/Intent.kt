package com.example.myapplication.myapplication.myapplication.myapplication.myapplication

class Intent {
    fun putStringArrayListExtra(s: String, minWeatherEditText: EditText?) {

    }

    fun putSringArrayListExtra(s: String, weatherConditionEditText: EditText?) {

    }

}
